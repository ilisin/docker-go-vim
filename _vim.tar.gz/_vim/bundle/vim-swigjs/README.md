Vim [swig](https://github.com/paularmstrong/swig) syntax highlighting
